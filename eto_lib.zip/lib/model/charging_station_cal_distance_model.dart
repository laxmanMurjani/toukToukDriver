class ChargingStationCalDistanceModel {
  String? chargingStationName;
  String? chargingStationAddress;
  String? chargingStationLat;
  String? chargingStationLong;
  String? chargingStationCall;
  double? chargingStationDistance;

  ChargingStationCalDistanceModel(
      {this.chargingStationName,
      this.chargingStationAddress,
      this.chargingStationLat,
      this.chargingStationLong,
      this.chargingStationCall,
      this.chargingStationDistance});

}