class SummaryListModel {
  String? summaryName;
  int? indexNo;

  SummaryListModel({this.summaryName, this.indexNo});
}
