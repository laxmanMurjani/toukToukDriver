// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:razorpay_flutter/razorpay_flutter.dart';
//
// void handlePaymentSuccess(PaymentSuccessResponse response) {
//   Get.snackbar("Payment Success", "SUCCESS: " + response.paymentId!,
//       backgroundColor: Colors.green.withOpacity(0.8), colorText: Colors.white);
// }
//
// void handlePaymentError(PaymentFailureResponse response) {
//   Get.snackbar("Payment Error",
//       "ERROR: " + response.code.toString() + " - " + response.message!,
//       backgroundColor: Colors.redAccent.withOpacity(0.8),
//       colorText: Colors.white);
// }
//
// void handleExternalWallet(ExternalWalletResponse response) {
//   Get.snackbar("External Wallet", "EXTERNAL_WALLET: " + response.walletName!,
//       backgroundColor: Colors.green.withOpacity(0.8), colorText: Colors.white);
// }
