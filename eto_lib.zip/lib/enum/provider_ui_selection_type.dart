enum ProviderUiSelectionType {
  searchingRequest,
  startedRequest,
  acceptedRequest,
  approvedRequest,
  arrivedRequest,
  pickedUpRequest,
  droppedRequest,
  completedRequest,
  none
}
